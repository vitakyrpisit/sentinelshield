/**
 * Production HTTP Resource Server for x402 SentinelShield.
 * Runs on port 3000, serving /health, /sentinelshield (x402 protected),
 * /.well-known/x402-manifest.json, and mounting Vite middlewares.
 */

import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import {
  handlePaidSentinelRequest,
  generatePaymentRequirements,
  PRODUCTION_PAY_TO,
  SENTINEL_PRICE_USDC,
  BASE_USDC_MAINNET,
  FACILITATOR_MAINNET
} from './src/services/x402ServerCore';
import { fetchLiveOnChainStatus } from './src/services/baseRpc';
import { createPublicClient, http } from 'viem';
import { base, baseSepolia } from 'viem/chains';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '5mb' }));

// 1. FREE HEALTH ENDPOINT (Prompt Section 9, Test 2)
app.get('/health', (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'ok',
    service: 'sentinelshield',
    network: 'base',
    payment: 'x402',
    price: `${SENTINEL_PRICE_USDC.toFixed(2)} USDC`
  });
});

// 2. MACHINE-READABLE DISCOVERY MANIFEST (Prompt Section 27)
app.get('/.well-known/x402-manifest.json', (_req: Request, res: Response) => {
  res.status(200).json({
    version: '1.0',
    service: 'SentinelShield Contract Risk Triage',
    description: 'Deterministic security audit, AST static vulnerability triage, and SARIF report generation.',
    pricing: {
      amount: '9500000',
      amountUSDC: 9.50,
      token: 'USDC',
      tokenAddress: BASE_USDC_MAINNET,
      network: 'eip155:8453',
      scheme: 'exact'
    },
    payTo: PRODUCTION_PAY_TO,
    facilitator: FACILITATOR_MAINNET,
    endpoint: '/sentinelshield',
    healthEndpoint: '/health',
    latencyExpectedMs: 1250,
    inputSchema: {
      type: 'object',
      properties: {
        contractAddress: { type: 'string', description: 'Ethereum/Base address (0x...)' },
        chain: { type: 'string', enum: ['base', 'ethereum'], default: 'base' },
        bytecode: { type: 'string', description: 'Optional runtime bytecode hex' },
        sourceCode: { type: 'string', description: 'Optional Solidity source' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        riskLevel: { type: 'string', enum: ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'SECURE'] },
        overallScore: { type: 'number', minimum: 0, maximum: 100 },
        summary: { type: 'string' },
        exploitability: { type: 'string' },
        findings: { type: 'array' },
        sarif: { type: 'object' }
      }
    }
  });
});

// 3. PAID SENTINELSHIELD ENDPOINT - BASE MAINNET (Prompt Section 10, Test 3)
app.post('/sentinelshield', async (req: Request, res: Response) => {
  let authPayload = req.body?.paymentAuthorization;

  // Check Authorization: x402 <base64> header
  const authHeader = req.headers['authorization'] || req.headers['x-402-authorization'];
  if (!authPayload && typeof authHeader === 'string') {
    if (authHeader.toLowerCase().startsWith('x402 ')) {
      try {
        const decoded = Buffer.from(authHeader.slice(5).trim(), 'base64').toString('utf8');
        authPayload = JSON.parse(decoded);
      } catch {
        // Fallback to raw string
      }
    }
  }

  const clientTxHash = (req.headers['x-402-tx-hash'] || req.headers['x-tx-hash'] || req.body?.txHash || req.body?.transactionHash) as string | undefined;

  const { statusCode, headers, body } = await handlePaidSentinelRequest(
    req.body || {},
    authPayload,
    'eip155:8453',
    clientTxHash
  );

  for (const [k, v] of Object.entries(headers)) {
    res.setHeader(k, v);
  }
  res.status(statusCode).json(body);
});

// 4. TESTNET ENDPOINT - BASE SEPOLIA (Prompt Section 15, Test 5)
app.post('/api/testnet/sentinelshield', async (req: Request, res: Response) => {
  let authPayload = req.body?.paymentAuthorization;
  const authHeader = req.headers['authorization'] || req.headers['x-402-authorization'];
  if (!authPayload && typeof authHeader === 'string' && authHeader.toLowerCase().startsWith('x402 ')) {
    try {
      const decoded = Buffer.from(authHeader.slice(5).trim(), 'base64').toString('utf8');
      authPayload = JSON.parse(decoded);
    } catch {}
  }

  const clientTxHash = (req.headers['x-402-tx-hash'] || req.headers['x-tx-hash'] || req.body?.txHash || req.body?.transactionHash) as string | undefined;

  const { statusCode, headers, body } = await handlePaidSentinelRequest(
    req.body || {},
    authPayload,
    'eip155:84532',
    clientTxHash
  );

  for (const [k, v] of Object.entries(headers)) {
    res.setHeader(k, v);
  }
  res.status(statusCode).json(body);
});

// 5. LIVE ON-CHAIN RPC STATUS ENDPOINT
app.get('/api/onchain/status', async (req: Request, res: Response) => {
  const network = (req.query.network as string) === 'base-sepolia' ? 'base-sepolia' : 'base-mainnet';
  try {
    const status = await fetchLiveOnChainStatus(PRODUCTION_PAY_TO, network);
    res.status(200).json(status);
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'RPC Error' });
  }
});

// 6. RUNTIME TRANSACTION VERIFIER (Prompt Section 21)
app.post('/api/verify/tx', async (req: Request, res: Response) => {
  const { txHash, network = 'base-mainnet' } = req.body;
  if (!txHash || typeof txHash !== 'string' || !txHash.startsWith('0x') || txHash.length !== 66) {
    return res.status(400).json({
      error: 'Invalid transaction hash format. Must be full 66-character hex hash starting with 0x.'
    });
  }

  const targetChain = network === 'base-sepolia' ? baseSepolia : base;
  const publicRpc = createPublicClient({
    chain: targetChain,
    transport: http(network === 'base-sepolia' ? 'https://sepolia.base.org' : 'https://mainnet.base.org')
  });

  try {
    const [tx, receipt] = await Promise.all([
      publicRpc.getTransaction({ hash: txHash as `0x${string}` }),
      publicRpc.getTransactionReceipt({ hash: txHash as `0x${string}` })
    ]);

    const isSuccess = receipt.status === 'success';

    res.status(200).json({
      txHash,
      network: targetChain.id === 8453 ? 'eip155:8453' : 'eip155:84532',
      blockNumber: Number(receipt.blockNumber),
      status: isSuccess ? 'confirmed' : 'failed',
      from: tx.from,
      to: tx.to,
      verification: 'RPC_VERIFIED',
      gasUsed: receipt.gasUsed.toString(),
      payoutAddressChecked: PRODUCTION_PAY_TO
    });
  } catch (err: any) {
    res.status(404).json({
      error: 'Transaction not found on chain or pending confirmation',
      details: err?.message
    });
  }
});

// 7. MOUNT VITE MIDDLEWARE (DEV) OR STATIC ASSETS (PROD)
async function startServer() {
  if (!isProduction) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[x402 Server] SentinelShield active on port ${PORT} (Base Mainnet payTo: ${PRODUCTION_PAY_TO})`);
  });
}

startServer();
